<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Meta -->
    <meta name="description" content="Responsive Bootstrap4 Dashboard Template">
    <meta name="author" content="ParkerThemes">
    <link rel="shortcut icon" href="{{asset('upload/Logo/logo.png')}}" />

    <!-- Title -->
    <title>Tow True Way</title>

    <!-- *************
      ************ Common Css Files *************
    ************ -->
    <!-- Bootstrap css -->
    <link rel="stylesheet" href="{{asset('admin_assets/css/bootstrap.min.css')}}">
    <!-- Icomoon Font Icons css -->
    <link rel="stylesheet" href="{{asset('admin_assets/fonts/style.css')}}">
    <!-- Main css -->
    <link rel="stylesheet" href="{{asset('admin_assets/css/main.css')}}">

    <!-- *************
      ************ Vendor Css Files *************
    ************ -->
    
    <!-- Data Tables -->

    <link rel="stylesheet" href="{{asset('admin_assets/vendor/datatables/dataTables.bs4.css')}}" />
    <link rel="stylesheet" href="{{asset('admin_assets/vendor/datatables/dataTables.bs4-custom.css')}}" />
    <link href="{{asset('admin_assets/vendor/datatables/buttons.bs.css')}}" rel="stylesheet" />
    <link rel="stylesheet" href="{{asset('admin_assets/vendor/summernote/summernote-bs4.css')}}" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
  
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.1.0-beta.1/css/select2.min.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.1.0-beta.1/js/select2.min.js"></script> -->

  </head>

  <body>

    <!-- Page wrapper start -->
    
<div class="page-wrapper">
      
      <!-- Sidebar wrapper start -->
      @include('admin.layouts.sidebar')
      <!-- Sidebar wrapper end -->

      <!-- Page content start  -->
      <div class="page-content">
        
        <!-- Main container start -->
        <div class="main-container">

          <!-- Theme switch start -->
          <a href="http://bootstrap.gallery/goldfinch/design1/index.html" class="theme-switch" target="_blank">Gradient Color Option</a>
          <!-- Theme switch end -->

          <!-- Header start -->
           @include('admin.layouts.topheader')
          <!-- Header end -->

          <!-- Page header start -->
          <div class="page-header">

            <!-- Breadcrumb start -->
            <ol class="breadcrumb">
              <li class="breadcrumb-item">Data Tables</li>
            </ol>
            <!-- Breadcrumb end -->

            <!-- App actions start -->
            <!-- <ul class="app-actions">
              <li>
                <a href="#">
                  <i class="icon-export"></i> Export
                </a>
              </li>
            </ul> -->
            <!-- App actions end -->
            <ul class="app-actions">
              <li>
            <button type="button" class="btn btn-primary" data-toggle="modal" data-target=".bd-example-modal-lg">Add Brand</button>

      <form action="{{url('/admin/brand')}}" method="post" enctype="multipart/form-data">{{csrf_field()}}
                  <div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-lg">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h5 class="modal-title" id="myLargeModalLabel">Add Brand (Physical Product)</h5>
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                          </button>
                        </div>
                        <div class="modal-body">
                          <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                             <div class="card">
                <div class="card-body">
                  <div class="row gutters">
                    <div class="col-xl-6 col-lglg-6 col-md-6 col-sm-6 col-6">
                      <div class="form-group">
                        <label for="inputName">Brand Name</label>
                        <input type="text" name="brandname" class="form-control" id="inputName" placeholder="Brand name">
                      </div>
                    </div>
                    
                    <div class="col-xl-6 col-lglg-6 col-md-6 col-sm-6 col-6">
                      <div class="form-group">
                      <label for="inputName">Status</label>
                    <select class="form-control form-control-lg" name="status">
                          <option>--Select--</option>
                          <option value="1">Active</option>
                          <option value="0">Inactive</option>
                        </select>
                    </div>
                     
                    </div>

                   <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                      <div class="form-group">
                        <label for="inputEmail">Meta Title</label>
                        <input type="text" name="metatitle" class="form-control" id="inputName" placeholder="Meta title">
                      </div>
                    </div>

                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
              
                <div class="form-group">
                  <label for="inputName">Description</label>
               <textarea class="form-control" name="description" id="exampleFormControlTextarea1" rows="2" placeholder="Start from here"></textarea>
              </div>
            </div>
                    
                    
          <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
              

                  <label for="exampleFormControlTextarea1">Brand Logo</label>
                        <input type="file" name="image">
                  
            </div>
            
            

                  </div>

                </div>
              </div>
            </div>
                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                          <input type="submit" class="btn btn-primary">
                        </div>
                      </div>
                    </div>

                  </div>
                </form>
                </li>
            </ul>


          </div>
          <!-- Page header end -->
          
          <!-- Row start -->
          <div class="row gutters">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            
              <div class="table-container">
                <div class="t-header">No Search Field</div>
                <div class="table-responsive">
                  <table id="copy-print-csv" class="table custom-table">
                    <thead>
                      <tr>

                        <th>Name</th>
                        <th>Phone</th>
                        <th>Email</th>
                        <th>Country</th>
                        <th>Product</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>Tiger Nixon</td>
                        <td>System Architect</td>
                        <td>Edinburgh</td>
                        <td>61</td>
                        <td>2011/04/25</td>
                        <td>$320,800</td>
                      </tr>
                      <tr>
                        <td>Garrett Winters</td>
                        <td>Accountant</td>
                        <td>Tokyo</td>
                        <td>63</td>
                        <td>2011/07/25</td>
                        <td>$170,750</td>
                      </tr>
                      <tr>
                        <td>Ashton Cox</td>
                        <td>Junior Technical Author</td>
                        <td>San Francisco</td>
                        <td>66</td>
                        <td>2009/01/12</td>
                        <td>$86,000</td>
                      </tr>
                      <tr>
                        <td>Cedric Kelly</td>
                        <td>Senior Javascript Developer</td>
                        <td>Edinburgh</td>
                        <td>22</td>
                        <td>2012/03/29</td>
                        <td>$433,060</td>
                      </tr>
                      <tr>
                        <td>Airi Satou</td>
                        <td>Accountant</td>
                        <td>Tokyo</td>
                        <td>33</td>
                        <td>2008/11/28</td>
                        <td>$162,700</td>
                      </tr>
                      <tr>
                        <td>Brielle Williamson</td>
                        <td>Integration Specialist</td>
                        <td>New York</td>
                        <td>61</td>
                        <td>2012/12/02</td>
                        <td>$372,000</td>
                      </tr>
                      <tr>
                        <td>Herrod Chandler</td>
                        <td>Sales Assistant</td>
                        <td>San Francisco</td>
                        <td>59</td>
                        <td>2012/08/06</td>
                        <td>$137,500</td>
                      </tr>
                      <tr>
                        <td>Rhona Davidson</td>
                        <td>Integration Specialist</td>
                        <td>Tokyo</td>
                        <td>55</td>
                        <td>2010/10/14</td>
                        <td>$327,900</td>
                      </tr>
                      <tr>
                        <td>Colleen Hurst</td>
                        <td>Javascript Developer</td>
                        <td>San Francisco</td>
                        <td>39</td>
                        <td>2009/09/15</td>
                        <td>$205,500</td>
                      </tr>
                      <tr>
                        <td>Sonya Frost</td>
                        <td>Software Engineer</td>
                        <td>Edinburgh</td>
                        <td>23</td>
                        <td>2008/12/13</td>
                        <td>$103,600</td>
                      </tr>
                      <tr>
                        <td>Jena Gaines</td>
                        <td>Office Manager</td>
                        <td>London</td>
                        <td>30</td>
                        <td>2008/12/19</td>
                        <td>$90,560</td>
                      </tr>
                      <tr>
                        <td>Quinn Flynn</td>
                        <td>Support Lead</td>
                        <td>Edinburgh</td>
                        <td>22</td>
                        <td>2013/03/03</td>
                        <td>$342,000</td>
                      </tr>
                      <tr>
                        <td>Charde Marshall</td>
                        <td>Regional Director</td>
                        <td>San Francisco</td>
                        <td>36</td>
                        <td>2008/10/16</td>
                        <td>$470,600</td>
                      </tr>
                      <tr>
                        <td>Haley Kennedy</td>
                        <td>Senior Marketing Designer</td>
                        <td>London</td>
                        <td>43</td>
                        <td>2012/12/18</td>
                        <td>$313,500</td>
                      </tr>
                      <tr>
                        <td>Tatyana Fitzpatrick</td>
                        <td>Regional Director</td>
                        <td>London</td>
                        <td>19</td>
                        <td>2010/03/17</td>
                        <td>$385,750</td>
                      </tr>
                      
                      
                      
                      
                    </tbody>
                  </table>
                </div>
              </div>

              

              

            
              

              

              

            </div>
          </div>
          <!-- Row end -->

        </div>
        <!-- Main container end -->

      </div>
      <!-- Page content end -->

    </div>

    <!-- Page wrapper end -->

    <!--**************************
      **************************
        **************************
              Required JavaScript Files
        **************************
      **************************
    **************************-->
    <!-- Required jQuery first, then Bootstrap Bundle JS -->

   
 -->
    <script src="{{asset('admin_assets/js/jquery.min.js')}}"></script>
    <script src="{{asset('admin_assets/js/bootstrap.bundle.min.js')}}"></script>
    <script src="{{asset('admin_assets/admin_assets/js/moment.js')}}"></script>


    <!-- *************
      ************ Vendor Js Files *************
    ************* -->
    <!-- Slimscroll JS -->
    <script src="{{asset('admin_assets/vendor/slimscroll/slimscroll.min.js')}}"></script>
    <script src="{{asset('admin_assets/vendor/slimscroll/custom-scrollbar.js')}}"></script>

    <!-- Summernote JS -->
    <script src="{{asset('admin_assets/vendor/summernote/summernote-bs4.js')}}"></script>
    <script>
      $(document).ready(function() {
        $('.summernote').summernote({
          height: '50px',
          tabsize: 2
        });
      });
    </script>
   

    
    
    <!-- Data Tables -->
    <script src="{{asset('admin_assets/vendor/datatables/dataTables.min.js')}}"></script>
    <script src="{{asset('admin_assets/vendor/datatables/dataTables.bootstrap.min.js')}}"></script>
    
    <!-- Custom Data tables -->
    <script src="{{asset('admin_assets/vendor/datatables/custom/custom-datatables.js')}}"></script>
    <script src="{{asset('admin_assets/vendor/datatables/custom/fixedHeader.js')}}"></script>

    <!-- Download / CSV / Copy / Print -->
    <script src="{{asset('admin_assets/vendor/datatables/buttons.min.js')}}"></script>
    <script src="{{asset('admin_assets/vendor/datatables/jszip.min.js')}}"></script>
    <script src="{{asset('admin_assets/cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js')}}"></script>
    <script src="{{asset('admin_assets/vendor/datatables/vfs_fonts.js')}}"></script>
    <script src="{{asset('admin_assets/vendor/datatables/html5.min.js')}}"></script>
    <script src="{{asset('admin_assets/vendor/datatables/buttons.print.min.js')}}"></script>

    


    <!-- Main JS -->
    <script src="{{asset('admin_assets/js/main.js')}}"></script>

  </body>


</html>